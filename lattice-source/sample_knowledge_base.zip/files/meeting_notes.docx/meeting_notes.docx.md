# Camera Team Weekly Sync - September 22, 2026

**Attendees:** J. Kim (lead), A. Patel, M. Chen, S. Lee, R. Gomez
**Location:** Conference Room 4B / video call

## Agenda

1. MCN5 test results review
2. EVT2 build schedule
3. Supplier update for lens assemblies

## Discussion

### MCN5 Test Results

A. Patel presented the Q3 test report. All metrics passed except distortion (1.2% vs. 1.0% target). The team agreed the issue is correctable in the ISP and does not require a lens redesign.

### EVT2 Build Schedule

The EVT2 build remains scheduled for October 20, 2026. M. Chen noted that the recalibrated distortion profile must be delivered by October 10 to be included in the build firmware.

### Supplier Update

S. Lee reported that the lens supplier has resolved the coating defect seen in August. Yield on the latest lot is 97.4%, up from 91.8%.

## Decisions

- Proceed with ISP-based distortion correction; no lens redesign.
- Keep the EVT2 date of October 20.

## Action Items

| Owner | Action | Due |
| --- | --- | --- |
| A. Patel | Deliver recalibrated distortion profile | 2026-10-10 |
| M. Chen | Integrate profile into EVT2 firmware | 2026-10-15 |
| S. Lee | Confirm supplier yield on next two lots | 2026-10-06 |
| R. Gomez | Update project budget for EVT2 | 2026-09-30 |

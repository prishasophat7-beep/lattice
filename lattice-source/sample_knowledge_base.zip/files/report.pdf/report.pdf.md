# Introduction

This report covers the Q3 2026 camera module testing results for the MCN5 image sensor. Testing was carried out at the Suwon optics lab between July 7 and September 12, 2026.

## Background

The MCN5 sensor is a 50 MP, 1/1.56-inch stacked CMOS sensor intended for mid-range smartphones. It was tested under various lighting conditions ranging from 10 lux (dim indoor) to 1,000 lux (overcast daylight).

![Figure](images/figure_000.png)

Signal-to-noise ratio improves steadily with illuminance and plateaus above 500 lux.

## Test Methodology

Each module was mounted on a calibrated optical bench and evaluated against ISO 12233 and ISO 15739 charts. Twenty production-sample modules were tested; values below are medians.

# Results

## Image Quality Metrics

| Test | Result | Target | Notes |
| --- | --- | --- | --- |
| MTF50 (center) | 0.42 cycles/pixel | >= 0.38 | Pass |
| MTF50 (corner) | 0.31 cycles/pixel | >= 0.28 | Pass |
| SNR @ 1000 lux | 38.1 dB | >= 36 dB | Pass |
| Distortion | 1.2% | <= 1.0% | Fail |
| Color accuracy (dE2000) | 3.4 | <= 4.0 | Pass |

![Figure](images/figure_001.png)

The MTF curve shows a corner fall-off consistent with the lens design, remaining above target.

# Conclusion

All tests passed except distortion, which exceeded the 1.0% limit by 0.2 percentage points. We recommend recalibrating the lens distortion correction profile in the ISP before the EVT2 build.

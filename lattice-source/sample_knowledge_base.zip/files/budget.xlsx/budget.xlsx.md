# budget.xlsx

## Sheet: Summary

| Category | FY2026 Actual ($K) | FY2027 Budget ($K) | Change |
| --- | --- | --- | --- |
| Personnel | 389 | 412 | +5.9% |
| Equipment | 142 | 186 | +31.0% |
| Software | 71 | 74 | +4.2% |
| Travel | 45 | 38 | -15.6% |
| Contingency | 50 | 60 | +20.0% |
| **Total** | **697** | **770** | **+10.5%** |

![Figure](images/figure_000.png)

## Sheet: Equipment Detail

| Item | Qty | Unit Cost ($K) | Total ($K) |
| --- | --- | --- | --- |
| Optical test bench | 1 | 92 | 92 |
| ISO 12233 chart set | 4 | 3.5 | 14 |
| Light booth (D65/A/TL84) | 2 | 28 | 56 |
| Thermal chamber rental | 6 | 4 | 24 |

## Sheet: Notes

Equipment increase is driven by the new optical bench required for EVT2 validation. Travel is reduced because supplier audits will be held remotely.

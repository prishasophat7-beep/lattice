# Plant Safety Rules

Safety rules that apply to every station on the assembly line.

## Personal protective equipment

Safety shoes and safety glasses are mandatory on the shop floor. Hearing protection is required where noise exceeds 85 dB(A). In the paint booth, wear a respirator with A2P3 filters and a disposable coverall.

## Lockout / tagout

Before any maintenance or jam clearing, isolate the energy source, apply your personal lock and tag, and test that the machine cannot start. Never remove another person's lock.

## Emergency stop

Red emergency stop buttons are located at every station. After an emergency stop, the line may only be restarted by the team leader after the cause is found.

## Reporting incidents

Report every injury, near miss or unsafe condition to the team leader within the same shift, and log it in the EHS system.

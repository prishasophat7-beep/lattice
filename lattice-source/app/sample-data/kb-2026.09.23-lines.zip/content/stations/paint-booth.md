# Paint Booth PB-2 Operating Procedure

Operating procedure for paint booth PB-2 (Station 7).

## Booth conditions

- Temperature: 22 to 26 °C
- Relative humidity: 55 to 70 %
- Downdraft air speed: 0.3 to 0.5 m/s

Do not start painting if the humidity alarm is active.

## Spray gun settings

| Coat | Gun | Pressure | Distance | Flash-off time |
|---|---|---|---|---|
| Primer | HVLP-1 | 2.0 bar | 15-20 cm | 10 min |
| Base coat | HVLP-2 | 1.8 bar | 15-20 cm | 5 min |
| Clear coat | HVLP-2 | 2.2 bar | 15-20 cm | 15 min |

## Curing

Bake at 60 °C for 30 minutes after the clear coat. Parts must cool to below 35 °C before handling.

## Filter replacement

Replace the ceiling filters every 800 operating hours, and the floor filters every 120 operating hours or when the pressure-drop gauge reads above 250 Pa.

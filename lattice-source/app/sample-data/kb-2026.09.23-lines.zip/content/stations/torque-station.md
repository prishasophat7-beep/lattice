# Station 3 Torque Tightening Manual

Work instructions for the DT-450 electric nutrunner at Station 3 (wheel hub assembly).

## Tool overview

The DT-450 is a DC electric nutrunner with a transducer and a controller (CTRL-7). The controller stores up to 16 programs (P1-P16).

## Torque specifications

| Joint | Fastener | Program | Target torque | Tolerance |
|---|---|---|---|---|
| Wheel hub bolts | M12 x 1.5 | P3 | 110 Nm | ±5 Nm |
| Brake caliper bolts | M10 | P4 | 65 Nm | ±3 Nm |
| Hub cap screws | M6 | P7 | 9 Nm | ±0.5 Nm |

Tighten wheel hub bolts in a star pattern. Final angle check: 30° to 45° after snug torque.

## Daily start-up check

1. Switch on the CTRL-7 controller and wait for the green READY lamp.
2. Run the tool on the test joint rig for 5 cycles on program P3.
3. Readings must be within 2% of the rig reference. If not, tag the tool and call maintenance.
4. Record the result in the shift log.

## Error codes

### E17 - Torque not reached

The fastener stopped rotating before the target torque. Usual causes: cross-threaded bolt, damaged thread, wrong program selected. Remove the bolt, inspect the thread, replace the bolt if damaged, and re-run.

### E22 - Angle out of window

Final angle exceeded 45°. The joint may be stripped or the washer missing. Quarantine the part and inform the team leader.

### E31 - Transducer fault

Transducer self-test failed. Stop using the tool immediately and swap to the spare DT-450 from the tool crib. Maintenance must recalibrate within 24 hours.

## Calibration

The DT-450 must be calibrated every 90 days or after 250,000 cycles, whichever comes first. Calibration is done by the metrology lab only.

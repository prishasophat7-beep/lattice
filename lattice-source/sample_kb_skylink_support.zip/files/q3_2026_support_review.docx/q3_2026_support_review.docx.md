**Q3 2026 Customer Support Review**

*Prepared by Support Operations for the leadership review on 6 October 2026.*

# Executive Summary

Q3 was a strong quarter for customer satisfaction and speed of response, but the R7 firmware 2.9.0 rollout in weeks 33 and 34 created a spike in contacts that we have not fully recovered from. Backlog older than 7 days grew 19% and is the main risk heading into Q4.

# Key Metrics

![Figure](images/figure_000.png)

*Figure 1: Support KPI dashboard for Q3 2026*

| Metric | Q2 2026 | Q3 2026 | Target | Status |
| --- | --- | --- | --- | --- |
| Tickets resolved | 11,556 | 12,480 | - | - |
| CSAT | 89.2% | 91.3% | 90% | On track |
| First response time (median) | 2h 51m | 2h 14m | 2h 30m | On track |
| First contact resolution | 58% | 61% | 65% | Behind |
| Backlog > 7 days | 180 | 214 | < 150 | At risk |

# Ticket Volume

Weekly volume rose from 870 tickets at the start of the quarter to a peak of 1,260 in week 34, when R7 firmware 2.9.0 was rolled out to all customers. Most of the extra contacts were about failed updates (error E-217) and a 5 GHz speed regression, both fixed in 2.9.1.

![Figure](images/figure_001.png)

*Figure 2: Weekly new tickets in Q3 2026*

# Top Contact Drivers

| Rank | Contact reason | Tickets | Share | Change vs Q2 |
| --- | --- | --- | --- | --- |
| 1 | No internet | 3,120 | 25% | -3% |
| 2 | Firmware update failure (E-217) | 1,870 | 15% | +212% |
| 3 | Slow Wi-Fi | 1,560 | 12.5% | +18% |
| 4 | Account and billing | 1,310 | 10.5% | -6% |
| 5 | Setup and installation | 1,190 | 9.5% | +2% |

# Customer Feedback

We analyzed 3,904 CSAT survey comments. Positive comments most often mention agent friendliness and quick fixes. Negative comments cluster around the firmware update issue and having to explain the problem again after escalation.

- "Agent fixed my internet in five minutes and explained what went wrong."
- "Third time contacting you about the same update error."
- "I had to repeat everything when I was transferred to Tier 2."

# Q4 Priorities

1. Reduce backlog older than 7 days to under 150 by 15 November with a dedicated backlog squad.
2. Introduce warm handoffs to Tier 2 so customers do not have to repeat themselves.
3. Publish an in-app guide for E-217 to deflect an estimated 40% of update-failure contacts.
4. Hire 6 seasonal agents for the holiday peak starting 1 December.

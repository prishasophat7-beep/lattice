**Skylink R7 Router - Tier 1 Troubleshooting Guide**

*Support Knowledge Article KA-0412, version 6. Applies to R7 firmware 2.8 and later.*

# 1 Introduction

This guide helps Tier 1 support agents resolve the most common Skylink R7 router issues on the first contact. Follow the sections in order unless the customer's symptom clearly matches a specific issue in Section 4.

Before starting, collect the router serial number (on the label under the device), the firmware version (Admin Console > System) and the customer's ISP. Log all three in the ticket.

# 2 LED Status Reference

The front panel LEDs are the fastest way to narrow down a problem. Ask the customer to describe the color and whether each light is solid or blinking.

![Figure](images/figure_000.png)

*Figure 1: R7 front panel with an amber INTERNET indicator*

| LED | Solid green | Blinking green | Amber | Off |
| --- | --- | --- | --- | --- |
| POWER | Normal | Booting / updating | Hardware fault | No power |
| INTERNET | Online | Traffic | WAN up, no IP from ISP | No WAN cable |
| 2.4G / 5G | Radio on | Traffic | Radio error | Radio disabled |
| LAN | Device connected | Traffic | - | No device |
| WPS | Paired | Pairing (2 min) | Pairing failed | Idle |

# 3 Diagnostic Flow

Use this flow for any 'no internet' contact. It resolves about 64% of these tickets without escalation.

![Figure](images/figure_001.png)

*Figure 2: No-internet diagnostic flowchart*

When closing a ticket, always use the resolution code shown in the flowchart so that reporting stays accurate.

# 4 Common Issues

## 4.1 No Internet

1. Confirm whether all devices or only one device is affected.
2. Check the INTERNET LED. If off, reseat the WAN cable at both ends.
3. Power-cycle the modem first, wait 2 minutes, then power-cycle the router.
4. If the INTERNET LED stays amber, ask the customer to contact their ISP to confirm there is no outage.
5. If still unresolved, collect WAN logs (Admin Console > Diagnostics > Export) and escalate.

## 4.2 Slow Wi-Fi

- Ask the customer to run a speed test next to the router, then in the problem room.
- Recommend the 5 GHz network for devices within two rooms of the router.
- Move the router off the floor and away from microwaves and fish tanks.
- Enable Auto Channel (Wireless > Advanced) to avoid congested channels.
- Confirm firmware is 2.9.1 or later, which fixes a 5 GHz throughput issue.

## 4.3 Firmware Update Failure

Error E-217 means the downloaded firmware image did not pass its checksum check, usually because the download was interrupted. The router keeps running the old firmware, so it is safe.

![Figure](images/figure_002.png)

*Figure 3: Admin Console showing firmware update error E-217*

Ask the customer to click **Retry download**. If it fails twice, send them the direct download link from KA-0388 and walk them through **Upload file manually**. Do not ask customers to factory reset for this error.

# 5 Escalation

Escalate only after completing the relevant steps above and attaching logs. Tickets escalated without logs will be returned.

| Condition | Escalate to | Target response |
| --- | --- | --- |
| No internet after full diagnostic flow | Tier 2 Network | 4 business hours |
| POWER LED amber (hardware fault) | RMA team | 1 business day |
| E-217 after manual upload | Tier 2 Firmware | 4 business hours |
| Suspected security issue (unknown admin login) | Security on-call | 1 hour, 24/7 |
| More than 20 tickets with same symptom in 1 hour | Incident manager | 15 minutes |

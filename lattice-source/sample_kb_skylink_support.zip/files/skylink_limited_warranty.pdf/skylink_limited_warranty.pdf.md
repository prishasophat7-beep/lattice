**Skylink Hardware Limited Warranty**

*Applies to products purchased in the United States and Canada on or after 1 March 2026.*

# 1 What This Warranty Covers

Skylink Networks Inc. ("Skylink") warrants that its hardware products will be free from defects in materials and workmanship under normal use during the warranty period. If a defect arises, Skylink will, at its option, repair the product, replace it with a new or refurbished product of equal or better functionality, or refund the purchase price.

This warranty applies only to the original purchaser and only to products purchased from Skylink or an authorized reseller. Proof of purchase is required.

# 2 Warranty Period

| Product | Warranty period | Extended option |
| --- | --- | --- |
| R7 and R9 routers | 3 years | Skylink Care+ extends to 5 years |
| M3 mesh nodes | 2 years | Skylink Care+ extends to 4 years |
| Power adapters and cables | 1 year | Not available |
| Refurbished products | 1 year | Not available |

# 3 What Is Not Covered

- Damage caused by accidents, liquid, fire, lightning or power surges.
- Products that have been opened, modified or repaired by anyone other than Skylink.
- Use of third-party or custom firmware.
- Cosmetic damage and normal wear and tear.
- Products with a removed or altered serial number.
- Loss of data or configuration settings.

# 4 How to Make a Claim

1. Contact Skylink Support at support.skylink.example or 1-800-555-0142.
2. Complete troubleshooting with an agent to confirm a hardware defect.
3. Receive a Return Merchandise Authorization (RMA) number by email.
4. Ship the product with the RMA number to the address provided. Skylink pays return shipping for valid claims.
5. Replacement products ship within 5 business days of receipt.

Customers with Skylink Care+ receive advance replacement: a replacement ships before the defective unit is returned.

# 5 Limitation of Liability

To the maximum extent permitted by law, Skylink is not liable for any indirect, incidental, special or consequential damages, including loss of data, revenue or profits, arising from the use of or inability to use the product. Skylink's total liability is limited to the amount paid for the product. Some jurisdictions do not allow these limitations, so they may not apply to you. This warranty gives you specific legal rights, and you may have other rights that vary by state or province.

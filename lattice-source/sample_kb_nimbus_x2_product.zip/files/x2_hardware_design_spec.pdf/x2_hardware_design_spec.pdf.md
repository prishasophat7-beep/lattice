**Nimbus X2 Smart Thermostat - Hardware Design Specification**

*Document HW-X2-001, Revision C, 12 September 2026. Confidential - internal use only.*

# 1 Overview

The Nimbus X2 is the second-generation smart thermostat from Nimbus Home. It replaces the X1 platform with a faster microcontroller, a larger color display, on-board CO2 sensing and a Wi-Fi 6 / Bluetooth LE 5.3 radio. The product targets North American low-voltage (24 VAC) residential HVAC systems, including conventional furnaces, heat pumps with auxiliary heat and two-stage cooling.

Key design goals for X2 were a 30% reduction in bill-of-materials cost relative to X1, support for installations without a common (C) wire through power stealing, and a standby consumption below 0.5 W to meet ENERGY STAR Smart Thermostat v1.1 requirements.

## 1.1 Scope

This document covers the main board (PCB-X2-MB), the relay board (PCB-X2-RB) and the interface between them. Firmware behavior is specified in FW-X2-004 and enclosure tooling in ME-X2-002. All voltages are nominal unless stated otherwise.

## 1.2 Revision History

| Rev | Date | Author | Changes |
| --- | --- | --- | --- |
| A | 2026-03-04 | L. Ortega | Initial release for EVT1 |
| B | 2026-06-19 | M. Chen | Added CO2 sensor, updated power budget |
| C | 2026-09-12 | M. Chen | Relay board rework, pinout corrections, compliance section |

# 2 System Architecture

The architecture is centered on a single STM32U585 microcontroller that handles the user interface, control loop and sensor fusion. A separate ESP32-C6 module provides Wi-Fi and BLE connectivity and communicates with the MCU over SPI. The block diagram below shows the main functional blocks and the buses that connect them.

![Figure](images/figure_000.png)

*Figure 1: System block diagram showing MCU, radio, sensors, display, relay board and power interfaces*

The relay board is isolated from the main board by optocouplers so that a fault on the HVAC side cannot damage the MCU. All high-current traces are routed on the relay board only.

## 2.1 Main Controller

The STM32U585 was selected for its TrustZone security, low-power modes and integrated graphics accelerator. It runs at 160 MHz with 2 MB of flash and 786 KB of SRAM. An external 16 MB QSPI flash stores UI assets and the secondary firmware slot for over-the-air updates.

- Core: Arm Cortex-M33 with TrustZone and FPU
- Clock: 160 MHz from a 16 MHz crystal plus 32.768 kHz RTC crystal
- Secure boot with keys stored in the OTP area
- Watchdog timeout: 4 seconds in normal operation

## 2.2 Wireless Connectivity

Wireless connectivity uses a pre-certified ESP32-C6-MINI module with an on-board PCB antenna. The antenna keep-out area must be at least 15 mm from the relay board and any metal backplate. BLE is used during setup for commissioning from the Nimbus mobile app; Wi-Fi is used for cloud connectivity and firmware updates.

# 3 Power Subsystem

The thermostat is powered from the 24 VAC R and C terminals through a full-bridge rectifier and a synchronous buck converter. When no C wire is present, the power-stealing circuit draws current through the W or Y call circuit while the relay is open, charging a 1 F supercapacitor that buffers the peak load during Wi-Fi transmission.

| Rail | Voltage | Max current | Source | Loads |
| --- | --- | --- | --- | --- |
| VIN | 24 VAC (18-30 VAC) | 250 mA | HVAC transformer | Rectifier input |
| V5 | 5.0 V | 400 mA | Buck converter | Relay coils, 3.3 V LDO |
| V3P3 | 3.3 V | 300 mA | LDO | MCU, radio, sensors, display logic |
| VBL | 12 V | 40 mA | Boost converter | Display backlight |

![Figure](images/figure_001.png)

*Figure 2: Measured 3.3 V current draw in each operating mode*

Peak current occurs when a relay is switching while Wi-Fi is transmitting. Firmware staggers these events by at least 50 ms so that power-stealing installations do not brown out.

# 4 Sensors

| Sensor | Part | Interface | Accuracy | Sample rate |
| --- | --- | --- | --- | --- |
| Temperature / humidity | Sensirion SHT45 | I2C (0x44) | +/-0.1 °C, +/-1.0% RH | 1 Hz |
| CO2 | Sensirion SCD41 | I2C (0x62) | +/-(40 ppm + 5%) | 1 per 30 s |
| Ambient light | Vishay VEML7700 | I2C (0x10) | +/-10% | 2 Hz |
| Occupancy | Panasonic EKMC1603111 | GPIO | 5 m range | Event driven |

## 4.1 Calibration

Each unit is calibrated in a thermal chamber at 18 °C and 28 °C. The resulting offset and gain are written to the MCU option bytes. Because the display and MCU warm the enclosure by up to 1.8 °C, firmware applies a self-heating compensation model that uses backlight level and CPU load as inputs. After compensation, reported temperature must be within +/-0.3 °C of the chamber reference.

# 5 Interfaces and Pinout

The main board connects to the relay board through a 10-pin 1.27 mm pitch board-to-board connector (J4). Revision C swapped pins 7 and 8 to simplify routing.

| Pin | Signal | Direction | Description |
| --- | --- | --- | --- |
| 1 | V5 | Out | 5 V supply to relay board |
| 2 | GND | - | Ground |
| 3 | RLY_W | Out | Heat relay drive |
| 4 | RLY_Y1 | Out | Cool stage 1 relay drive |
| 5 | RLY_Y2 | Out | Cool stage 2 relay drive |
| 6 | RLY_G | Out | Fan relay drive |
| 7 | RLY_OB | Out | Heat pump reversing valve |
| 8 | C_DET | In | C-wire present detect |
| 9 | PS_EN | Out | Power-stealing enable |
| 10 | GND | - | Ground |

# 6 Environmental and Compliance

- Operating temperature: 0 to 45 °C; storage -20 to 60 °C
- Humidity: 5 to 90% RH non-condensing
- FCC Part 15 Subpart B and C; ISED RSS-247
- UL 60730-1 and UL 60730-2-9 (automatic electrical controls)
- ENERGY STAR Smart Thermostat v1.1
- RoHS 3 and REACH compliant

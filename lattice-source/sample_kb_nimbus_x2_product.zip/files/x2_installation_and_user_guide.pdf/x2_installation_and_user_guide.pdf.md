**Nimbus X2 Installation and User Guide**

*For firmware 3.2 and later. Read all instructions before installing.*

# 1 Safety Information

The Nimbus X2 is designed for 24 V low-voltage heating and cooling systems only. Improper installation can damage your equipment or cause injury. If you are not comfortable working with household wiring, contact a licensed HVAC professional.

![Figure](images/figure_000.png)

*Figure 1: Warning label printed on the back of the X2 backplate*

- Do not connect to 120 V or 240 V line-voltage heating systems (for example baseboard heaters).
- Do not install in bathrooms or other locations where the unit may get wet.
- Keep the thermostat away from direct sunlight, drafts and heat sources such as lamps.

# 2 What's in the Box

- Nimbus X2 thermostat display unit
- Backplate with built-in level
- Trim plate (covers old thermostat marks)
- 4 screws and 4 wall anchors
- Wire labels sticker sheet
- Power adapter kit (PAK-2) for systems without a C wire
- Quick start card

# 3 Installation

Installation typically takes about 30 minutes. You will need a Phillips screwdriver, a drill with a 3/16-inch bit for the anchors, and your smartphone with the Nimbus app installed.

## 3.1 Wiring

Before removing your old thermostat, take a photo of its wiring and use the included stickers to label each wire by the terminal it was connected to. Wire color is not always a reliable indicator; always label by terminal letter.

![Figure](images/figure_001.png)

*Figure 2: Terminal wiring for a conventional heat/cool system with fan*

| Terminal | Typical color | Function | Required? |
| --- | --- | --- | --- |
| R / Rh / Rc | Red | 24 VAC power from transformer | Yes |
| C | Blue or black | Common (return path for 24 VAC) | Recommended |
| W / W1 | White | Heat stage 1 | If you have heating |
| Y / Y1 | Yellow | Cooling stage 1 (or compressor for heat pumps) | If you have cooling |
| G | Green | Fan | Recommended |
| O/B | Orange or dark blue | Heat pump reversing valve | Heat pumps only |

## 3.2 Mounting

1. Turn off power to your HVAC system at the circuit breaker.
2. Remove the old thermostat and label the wires.
3. Hold the X2 backplate against the wall, level it using the built-in bubble level and mark the screw holes.
4. Drill holes, insert the anchors and screw the backplate to the wall.
5. Insert each labeled wire into the matching terminal until the button pops up.
6. Snap the display onto the backplate and turn the power back on.

# 4 Using Your Thermostat

After power-up, X2 guides you through setup on screen and in the Nimbus app. The home screen shows the current indoor temperature in large digits, the target temperature and what the system is doing right now.

![Figure](images/figure_002.png)

*Figure 3: X2 home screen while heating*

Turn the outer ring to change the target temperature and press the display to open the menu. The three buttons at the bottom of the screen open the mode, fan and schedule settings.

## 4.1 Modes

| Mode | What it does | Best for |
| --- | --- | --- |
| Heat | Heats to the set temperature | Winter |
| Cool | Cools to the set temperature | Summer |
| Auto | Keeps temperature between a low and high set point | Spring and fall |
| Eco | Uses wider set points when nobody is home | Saving energy |
| Off | Heating and cooling are off; fan can still run | Open-window days |

## 4.2 Schedules

You can create up to 8 schedule points per day in the Nimbus app. With **Adaptive Recovery** turned on, X2 learns how long your home takes to heat or cool and starts early so that the target temperature is reached at the scheduled time, not after it.

# 5 Troubleshooting

If X2 detects a problem it shows an error code on screen and sends a notification to the Nimbus app. Heating and cooling may pause until the problem is resolved.

![Figure](images/figure_003.png)

*Figure 4: Example error screen for code E4*

| Code | Meaning | What to do |
| --- | --- | --- |
| E1 | No power on R wire | Check the breaker and the R wire connection |
| E2 | Power stealing unstable | Install the PAK-2 adapter or connect a C wire |
| E3 | Wi-Fi authentication failed | Re-enter the Wi-Fi password in the app |
| E4 | Temperature sensor not responding | Hold MENU for 10 s to restart; contact support if it returns |
| E5 | Relay stuck | Turn off power at breaker and contact support |
| E6 | Firmware image invalid | Device will roll back automatically; retry update later |

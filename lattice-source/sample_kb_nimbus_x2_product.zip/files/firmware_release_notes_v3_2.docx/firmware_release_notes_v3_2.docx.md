**Nimbus X2 Firmware 3.2.0 Release Notes**

*Release date: 22 September 2026. Rollout: staged, 10% -> 50% -> 100% over two weeks.*

# Highlights

- **Adaptive Recovery** learns your home's heating and cooling rates and pre-conditions before schedule changes.
- **Monthly Energy Reports** in the Nimbus app compare usage with the previous year.
- Boot time reduced from 9.4 s to 5.1 s.
- Fixes brown-out resets on some power-stealing installations (E2 errors).

# New Features

## Adaptive Recovery

Adaptive Recovery observes how quickly the home heats and cools over the first 7 days after it is enabled. It then starts heating or cooling ahead of each schedule change so the target is reached on time. Early start is capped at 2 hours and is disabled in Eco mode. The feature is on by default for new installs and off by default for existing users, who will be prompted in the app.

## Energy Reports

On the first day of each month, the app generates an energy report showing heating, cooling and Eco runtime, plus a comparison with the same month last year. Reports require at least 30 days of history.

![Figure](images/figure_000.png)

*Figure 1: Energy report screen in the Nimbus mobile app*

# Bug Fixes

| ID | Issue | Affected versions |
| --- | --- | --- |
| FW-1822 | Brown-out reset during Wi-Fi TX on power-stealing installs (E2) | 3.0.0 - 3.1.4 |
| FW-1850 | Schedule shifted by one hour after daylight saving change | 3.1.0 - 3.1.4 |
| FW-1861 | Humidity reading stuck at 0% after sensor soft reset | 3.1.2 - 3.1.4 |
| FW-1877 | Fan kept running for 90 s after cooling ended despite 'Fan: Auto' | 3.1.4 |
| FW-1893 | Display did not wake on approach when ambient light below 5 lux | 3.0.0 - 3.1.4 |
| FW-1902 | BLE setup failed on some Android 16 devices | 3.1.3 - 3.1.4 |

# Known Issues

- On some early EVT units, the update log shows 'display calibration table missing'. This is harmless; default calibration is used. (FW-1910)
- Energy reports may take up to 24 hours to appear for dual-fuel heat pump systems. (FW-1915)

# Upgrade Procedure

Most customers receive the update automatically overnight. Lab and field-test units can be updated manually with the nimbus-cli tool:

1. Connect your computer to the same network as the thermostat.
2. Run **nimbus-cli device update --serial <serial> --fw 3.2.0**.
3. Wait for the device to reboot (about 60 seconds). Do not remove the display during the update.
4. Confirm the version under Menu > Settings > About.

![Figure](images/figure_001.png)

*Figure 2: Example nimbus-cli output for a successful update to 3.2.0*

# Compatibility

| Component | Minimum version | Notes |
| --- | --- | --- |
| X2 hardware | Rev B main board | Rev A (EVT1) units not supported |
| Nimbus app (iOS) | 5.8.0 | Required for Energy Reports |
| Nimbus app (Android) | 5.8.1 | Includes BLE fix for Android 16 |
| nimbus-cli | 2.4.0 | Lab/field-test use only |
